#ifndef ATTRIBUTION_H
#define ATTRIBUTION_H

#include <QDialog>
#include "DB_header.h"

namespace Ui {
class Attribution;
}

class Attribution : public QDialog
{
    Q_OBJECT

public:
    explicit Attribution(QWidget *parent = nullptr);
    ~Attribution();

private slots:
    void on_pushButton_u6_clicked();

    void on_pushButton_clicked();

    void on_pushButton_1_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

private:
    Ui::Attribution *ui;
};

#endif // ATTRIBUTION_H
