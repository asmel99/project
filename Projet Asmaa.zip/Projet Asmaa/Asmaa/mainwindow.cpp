#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ptrAjouter_pc = new Ajouter_pc();
    ptrAttribution = new Attribution();
    ptrSuivi = new Suivi();
}

MainWindow::~MainWindow()
{
    delete ptrAjouter_pc;
    delete ptrAttribution;
    delete ptrSuivi;
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    ptrAjouter_pc->show();
}


void MainWindow::on_pushButton_2_clicked()
{
    ptrAttribution->show();
}


void MainWindow::on_pushButton_3_clicked()
{
    ptrSuivi->show();
}

