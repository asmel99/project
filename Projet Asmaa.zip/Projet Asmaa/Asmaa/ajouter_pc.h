#ifndef AJOUTER_PC_H
#define AJOUTER_PC_H

#include <QDialog>
#include "DB_header.h"

namespace Ui {
class Ajouter_pc;
}

class Ajouter_pc : public QDialog
{
    Q_OBJECT

public:
    explicit Ajouter_pc(QWidget *parent = nullptr);
    ~Ajouter_pc();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Ajouter_pc *ui;
};

#endif // AJOUTER_PC_H
