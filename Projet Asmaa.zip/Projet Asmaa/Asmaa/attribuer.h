#ifndef ATTRIBUER_H
#define ATTRIBUER_H

#include <QDialog>

namespace Ui {
class Attribuer;
}

class Attribuer : public QDialog
{
    Q_OBJECT

public:
    explicit Attribuer(QWidget *parent = nullptr);
    ~Attribuer();

private:
    Ui::Attribuer *ui;
};

#endif // ATTRIBUER_H
