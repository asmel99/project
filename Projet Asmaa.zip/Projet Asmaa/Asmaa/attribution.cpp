#include "attribution.h"
#include "ui_attribution.h"

Attribution::Attribution(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Attribution)
{
    ui->setupUi(this);

}

Attribution::~Attribution()
{
    delete ui;

}


void processButton(QString numSerie)
{

    QSqlDatabase database =  QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/pc/Desktop/3IIR/POO C++/Project s1/database/project.db");

    if(QFile::exists("C:/Users/pc/Desktop/3IIR/POO C++/Project s1/database/project.db")){
        qDebug() <<"Database file exist";
    }
    else{
        qDebug() <<"Database file don't exist";
        return;
    }

    if(!database.open()){
        qDebug() <<"unable to open Database";
    }
    else{
        qDebug() <<"Database open";
    }

    QSqlQuery query(database);

    query.prepare("select * from ordinateur where Num_serie = '%" + numSerie + "%')");
    if(query.exec()){
        qDebug() << "Query executed successfully";
    } else {
        qDebug() << "Query execution failed: " << query.lastError().text();
    }
    query.exec();
    qDebug() <<"Last query : "<< query.lastQuery();
    qDebug() <<"Last error : "<< query.lastError().text();

    query.prepare("SELECT Modele FROM ordinateur WHERE Num_serie = :numSerie");
    query.bindValue(":numSerie", numSerie);

    // Execute the SELECT query
    if(query.exec()){
        if(query.next()) {
            QString model = query.value(0).toString();
            qDebug() << "Model: " << model;
            query.prepare("UPDATE ordinateur SET Attribution = 'Utilisateur 1' WHERE Num_serie = :numSerie");
            query.bindValue(":numSerie", numSerie);
            if(query.exec()){
                qDebug() << "Update query executed successfully";
            } else {
                qDebug() << "Update query execution failed: " << query.lastError().text();
            }
        } else {
            qDebug() << "No row fetched";
        }
    } else {
        qDebug() << "Select query execution failed: " << query.lastError().text();
    }


    database.close();
}

void Attribution::on_pushButton_1_clicked()
{
    processButton(ui->lineEdit_1->text());
}

void Attribution::on_pushButton_2_clicked()
{
    processButton(ui->lineEdit_2->text());
}

void Attribution::on_pushButton_3_clicked()
{
    processButton(ui->lineEdit_3->text());
}

void Attribution::on_pushButton_4_clicked()
{
    processButton(ui->lineEdit_4->text());
}

void Attribution::on_pushButton_5_clicked()
{
    processButton(ui->lineEdit_5->text());
}

void Attribution::on_pushButton_6_clicked()
{
    processButton(ui->lineEdit_6->text());
}

