#ifndef DB_HEADER_H
#define DB_HEADER_H

#include <QSqlDatabase>
#include <QSqlDriver>
#include <QSqlError>
#include <QSqlQuery>
#include <QDebug>
#include <QSqlTableModel>
#include <QFile>

#endif // DB_HEADER_H
