#include "suivi.h"
#include "ui_suivi.h"

Suivi::Suivi(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Suivi)
{
    ui->setupUi(this);
}

Suivi::~Suivi()
{
    delete ui;
}





void Suivi::on_tableView_activated(const QModelIndex &index)
{
    QSqlDatabase database =  QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/pc/Desktop/3IIR/POO C++/Project s1/database/project.db");

    if(QFile::exists("C:/Users/pc/Desktop/3IIR/POO C++/Project s1/database/project.db")){
        qDebug() <<"Database file exist";
    }
    else{
        qDebug() <<"Database file don't exist";
        return;
    }

    if(!database.open()){
        qDebug() <<"unable to open Database";
        return;
    }
    else{
        qDebug() <<"Database open";
    }

    QSqlQuery query(database);

    query.prepare("SELECT * FROM ordinateur");
    if(query.exec()){
        qDebug() << "Query executed successfully";
    } else {
        qDebug() << "Query execution failed: " << query.lastError().text();
        return;
    }

    QSqlQueryModel *model = new QSqlQueryModel();
    model->setQuery(query);
    ui->tableView->setModel(model);

    database.close();
}




void Suivi::on_pushButton_clicked()
{
    QString  numSerie = ui->lineEdit_numSerie->text();

    QSqlDatabase database =  QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/pc/Desktop/3IIR/POO C++/Project s1/database/project.db");

    if(QFile::exists("C:/Users/pc/Desktop/3IIR/POO C++/Project s1/database/project.db")){
        qDebug() <<"Database file exist";
    }
    else{
        qDebug() <<"Database file don't exist";
        return;
    }

    if(!database.open()){
        qDebug() <<"unable to open Database";
    }
    else{
        qDebug() <<"Database open";
    }

    QSqlQuery query(database);

    query.prepare("select * from ordinateur where Num_serie = '%" + numSerie + "%')");
    if(query.exec()){
        qDebug() << "Query executed successfully";
    } else {
        qDebug() << "Query execution failed: " << query.lastError().text();
    }
    query.exec();
    qDebug() <<"Last query : "<< query.lastQuery();
    qDebug() <<"Last error : "<< query.lastError().text();

    query.prepare("SELECT Modele FROM ordinateur WHERE Num_serie = :numSerie");
    query.bindValue(":numSerie", numSerie);

    // Execute the SELECT query
    if(query.exec()){
        if(query.next()) {
            QString model = query.value(0).toString();
            qDebug() << "Model: " << model;
            query.prepare("UPDATE ordinateur SET Etat_Machine = 'Repare recement' WHERE Num_serie = :numSerie");
            query.bindValue(":numSerie", numSerie);
            if(query.exec()){
                qDebug() << "Update query executed successfully";
            } else {
                qDebug() << "Update query execution failed: " << query.lastError().text();
            }
        } else {
            qDebug() << "No row fetched";
        }
    } else {
        qDebug() << "Select query execution failed: " << query.lastError().text();
    }


    database.close();
}

