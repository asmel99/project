#ifndef SUIVI_H
#define SUIVI_H

#include <QDialog>
#include "DB_header.h"

namespace Ui {
class Suivi;
}

class Suivi : public QDialog
{
    Q_OBJECT

public:
    explicit Suivi(QWidget *parent = nullptr);
    ~Suivi();

private slots:
    void on_tableView_activated(const QModelIndex &index);

    void on_pushButton_clicked();

private:
    Ui::Suivi *ui;
};

#endif // SUIVI_H
