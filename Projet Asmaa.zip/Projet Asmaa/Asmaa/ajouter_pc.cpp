#include "ajouter_pc.h"
#include "ui_ajouter_pc.h"

Ajouter_pc::Ajouter_pc(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Ajouter_pc)
{
    ui->setupUi(this);
}

Ajouter_pc::~Ajouter_pc()
{
    delete ui;
}

void Ajouter_pc::on_pushButton_clicked()
{
    QString  numSerie = ui->lineEdit_numSerie->text();
    QString  marque = ui->lineEdit_marque->text();
    QString  modele = ui->lineEdit_modele->text();
    QString  etat = ui->comboBox_etatMachime->currentText();
    QString  si = ui->comboBox_SI->currentText();

    QSqlDatabase database =  QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/pc/Desktop/3IIR/POO C++/Project s1/database/project.db");

    if(QFile::exists("C:/Users/pc/Desktop/3IIR/POO C++/Project s1/database/project.db")){
        qDebug() <<"Database file exist";
    }
    else{
        qDebug() <<"Database file don't exist";
        return;
    }

    if(!database.open()){
        qDebug() <<"unable to open Database";
    }
    else{
        qDebug() <<"Database open";
    }

    QSqlQuery query(database);

    query.prepare("insert into ordinateur (Num_serie,Marque,Modele,Etat_Machine,SE) values('" + numSerie + "','" + marque + "','" + modele + "','" + etat + "','" + si + "')");
    if(query.exec()){
        qDebug() << "Query executed successfully";
    } else {
        qDebug() << "Query execution failed: " << query.lastError().text();
    }
    query.exec();
    qDebug() <<"Last error : "<< query.lastError().text();
    database.close();

}

