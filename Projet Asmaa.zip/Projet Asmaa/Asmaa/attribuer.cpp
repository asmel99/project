#include "attribuer.h"
#include "ui_attribuer.h"

Attribuer::Attribuer(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Attribuer)
{
    ui->setupUi(this);
}

Attribuer::~Attribuer()
{
    delete ui;
}
